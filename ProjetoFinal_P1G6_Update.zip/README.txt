No servidor da aula a stored procedure sp_updatePatient n�o estar� inicializada, pois eu no sab�do de 
manh� por volta da 1h estava a tentar resolver um bug e perdi o acesso ao servidor ao fim de ter feito 
drop � stored procedure...

Pe�o desculpa pelo atraso, mas foi com o objetivo de entregar um trabalho mais completo.