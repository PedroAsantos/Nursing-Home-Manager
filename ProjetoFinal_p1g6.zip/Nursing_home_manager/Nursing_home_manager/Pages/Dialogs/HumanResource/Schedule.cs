﻿namespace Nursing_home_manager.Pages.Dialogs.HumanResource
{
    internal class Schedule
    {
    }
}