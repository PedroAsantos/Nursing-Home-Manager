﻿namespace Nursing_home_manager.DataModels
{
    public enum ApplicationPage
    {
        /// <summary>
        /// The initial page
        /// </summary>
        PatientsPage=0,
        HumanResourcesPage=1,
    }
}
